package TestMethod;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FailedlogintoGitHub {
	public WebDriver driver;
	public String gitHUB = "https://www.github.com";
	@BeforeTest
		public void navigateGitHub()
		{
		  driver = new FirefoxDriver();
		  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		  driver.get(gitHUB);
		  driver.manage().window().maximize();
		}
	@Test
	    public void SuccessfullLoginandValidate()
	    {
		driver.findElement(By.xpath("html/body/header/div/div/div/a[2]")).click();
		driver.findElement(By.id("login_field")).sendKeys("invalid@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Netm0an123");
		driver.findElement(By.xpath("//*[@id='login']/form/div[4]/input[3]")).click();
		System.out.println(" Login test failed,Then we need verify");
		Assert.assertTrue(driver.getTitle().contains("login"),"User is not able to login because Invalid credentials");
		System.out.println("Page Text Verified :- User can able to login successfully");
		
	    }	
	@AfterMethod
	    public void Taskcompleted() 
	    {
	    driver.quit();
	    }
}
